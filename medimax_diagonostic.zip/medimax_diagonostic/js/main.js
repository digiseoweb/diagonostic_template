
/* ANIMATED ICON BAR */

function myFunction(e){
	
	e.classList.toggle("change");
}